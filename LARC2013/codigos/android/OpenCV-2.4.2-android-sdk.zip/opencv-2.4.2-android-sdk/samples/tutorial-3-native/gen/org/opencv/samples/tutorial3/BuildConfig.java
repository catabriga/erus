/** Automatically generated file. DO NOT MODIFY */
package org.opencv.samples.tutorial3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}